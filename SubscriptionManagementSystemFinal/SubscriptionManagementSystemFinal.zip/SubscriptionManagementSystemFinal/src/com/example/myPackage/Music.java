package com.example.myPackage;

import java.util.*;

public interface Music{

    public void addMusic(Song song);
    public void removeMusic(Song song);
    public void displayLyrics(Song song);
    public int setCategory();
    public void displayList();
    public void playMusic();
    public void displayAd();















}