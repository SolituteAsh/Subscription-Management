package com.example.myPackage;



import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Netflix extends Subscription {

    boolean autoRenewal;

    String category;

    public boolean isAutoRenewal() {
        return autoRenewal;
    }

    public void setAutoRenewal(boolean autoRenewal) {
        this.autoRenewal = autoRenewal;
    }

    public String getCategory() {
        return category;
    }

    public int setCategory() {
        // function returns if the category has been successfully set
        String cateGory;
        displayPlans();
        Scanner scanner=new Scanner(System.in);
        cateGory=scanner.nextLine();
        // do balance check for category selection
        if(cateGory.equals("Basic")){
            System.out.println("You have chosen basic category plan");
            this.category = cateGory;
            return 1;
        }
        else if(cateGory.equals("Individual")){
            System.out.println("You have chosen standard category plan");
            this.category = cateGory;
            return 1;
        }
        else if(cateGory.equals("Premium")){
            System.out.println("You have chosen premium category plan");
            this.category = cateGory;
            return 1;

        }
        else{
            System.out.println("Category not found ! Please Try again");
            return 0;
        }




    }

    public Netflix(int durationInMonths, String name, int costPerYear, int costPerMonth, boolean monthlyRenewalOrNot, Calendar startDate, Calendar endDate, Boolean autoRenewal, String category) {
        super(durationInMonths, "Netflix", costPerYear, costPerMonth, monthlyRenewalOrNot, startDate, endDate,true);
        this.autoRenewal=autoRenewal;
        this.category=category;

    }
    @Override
    public  void displayPlans(){
        System.out.println("Netflix Plans:");
        System.out.println("Basic Plan Monthly Cost:199");
        System.out.println("Standard Plan Monthly Cost:499");
        System.out.println("Premium Plan Monthly Cost:699");


    }

    public void getType() {
        System.out.println("Netflix is a subscription-based streaming service.");
    }


    public void language() {
        System.out.println("Netflix offers content in multiple languages.");
    }


    public void reward() {
        System.out.println("Netflix does not offer a reward program for its subscribers.");
    }










}
