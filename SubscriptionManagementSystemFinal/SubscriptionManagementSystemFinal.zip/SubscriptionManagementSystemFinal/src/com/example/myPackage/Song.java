package com.example.myPackage;

public class Song {
    String name;
    String lyrics;
}
