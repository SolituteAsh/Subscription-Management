package com.example.myPackage;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

public class Spotify extends Subscription implements Music{

    //things to be done

    //add songs count as an member variable


    private String name;

    ArrayList<Song> playlist;
    int playTime;
    boolean autoRenewal;
    String category;
    public Spotify(int durationInMonths, String name, int costPerYear, int costPerMonth, boolean monthlyRenewalOrNot, Calendar startDate, Calendar endDate, Boolean autoRenewal, String category) {
        super(durationInMonths, "Spotify", costPerYear, costPerMonth, monthlyRenewalOrNot, startDate, endDate,true);
        this.autoRenewal=autoRenewal;
        this.category=category;

    }
    public int setCategory() {
        // function returns if the category has been successfully set
        String cateGory;
        displayPlans();
        Scanner scanner=new Scanner(System.in);
        cateGory=scanner.nextLine();
        // do balance check for category selection
        if(cateGory.equals("Basic")){
            System.out.println("You have chosen basic category plan");
            this.category = cateGory;
            return 1;
        }
        else if(cateGory.equals("Standard")){
            System.out.println("You have chosen standard category plan");
            this.category = cateGory;
            return 1;
        }
        else if(cateGory.equals("Premium")){
            System.out.println("You have chosen premium category plan");
            this.category = cateGory;
            return 1;

        }
        else{
            System.out.println("Category not found ! Please Try again");
            return 0;
        }
    }

    public void addMusic(Song song) {
        int count = playlist.size();
        if (category.equals("Basic")) {
            //System.out.println("You can have a maximum of 5 songs in yur playlist!")
            playlist.add(song);
            count++;
            if (count > 5) {
                System.out.println("Basic subscription can hold only 5 songs in your playlist!");

            }
        }
        if (category.equals("Standard")) {
            //System.out.println("You can have a maximum of 5 songs in yur playlist!")
            playlist.add(song);
            count++;
            if (count > 10) {
                System.out.println("Standard subscription can hold only 10 songs in your playlist!");

            }
        }
        if (category.equals("Premium")) {
            //System.out.println("You can have a maximum of 5 songs in yur playlist!")
            playlist.add(song);
        }
    }
        public void removeMusic(Song song){
            playlist.remove(song);
        }
        public void playMusic(){

            if(category.equals("Basic")){
                for(Song song:playlist){
                    System.out.println(song.name);
                    displayAd();
                }
            }
            if(category.equals("Standard")){
                for(Song song:playlist){
                    System.out.println(song.name);
                    displayAd();
                }
            }
            //no ads for premium
            if(category.equals("Premium")){
                for(Song song:playlist){
                    System.out.println(song.name);

                }
            }




        }
        public void displayLyrics(Song song){
            if(category.equals("Premium")){
                System.out.println("Lyrics of the song:\n"+song.lyrics);
            }
            else{
                System.out.println("You need Premium subscription to view the lyrics!");
            }
        }

public void displayPlans(){
            System.out.println("Basic subscription - Cost 49/Month Features: 5 songs in playlist ");
            System.out.println("Standard subscription Cost 69/Month can hold only 10 songs in your playlist!");
            System.out.println("Premium subscription Cost 99/month can hold  unlimited songs in your playlist  and  No ads ");
        }
// check if it does playlist
       public  void displayList(){
            System.out.println("Playlist:\n"+playlist);
        }
//to check if payment has been processsed then proceed
        //also should check if category is in the three possibilities
        public int setCategory(boolean PaymentProcessed, String category){
            if(PaymentProcessed){
                if(category.equals("Basic") || category.equals("Standard") || category.equals("Premium")){
                    return 1;
                }
                else{
                    System.out.println("You have not paid for your subscription or the subscription type that has been entered is invalid please try again!");
                    return 0;
                }
            }
            return 0;
        }


        public void displayAd(){
            //this will pause the execution for 2000 milliseconds to simulate
            //display of adds remove it if it doesn't work
            System.out.println("Advertisement is being displayed please wait");
            try{
                Thread.sleep(2000);
            }catch(InterruptedException e){
            }

        }










    }